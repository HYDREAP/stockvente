package projetTest.beans;

public class RechercheBean {
    
    public String nomProduit;
    public double valeurProduit;
    public int quantiteeProdut;
    public String garantieProduit;
    
    public RechercheBean() {
    }

    public String getNomProduit() {
        return nomProduit;
    }

    public void setNomProduit( String nomProduit ) {
        this.nomProduit = nomProduit;
    }

    public double getValeurProduit() {
        return valeurProduit;
    }

    public void setValeurProduit( double valeurProduit ) {
        this.valeurProduit = valeurProduit;
    }

    public int getQuantiteeProdut() {
        return quantiteeProdut;
    }

    public void setQuantiteeProdut( int quantiteeProdut ) {
        this.quantiteeProdut = quantiteeProdut;
    }

    public String getGarantieProduit() {
        return garantieProduit;
    }

    public void setGarantieProduit( String garantieProduit ) {
        this.garantieProduit = garantieProduit;
    }
    
    

}
